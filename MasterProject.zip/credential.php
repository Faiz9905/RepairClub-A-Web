<?php
define("API Key", 'zLPkmVy8ibM-q0zlxD7uyIFFk2hpaEy02LsIlUlT77');
define("Mobile", '');
?>