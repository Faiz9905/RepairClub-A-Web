<?php
  session_start();

  

  if(isset($_POST['sendotp']))
  {
    $number=$_POST['number'];
require('textlocal.class.php');

$textlocal = new Textlocal(false, false, 'zLPkmVy8ibM-Xex836WbrsIPPvAK6rOdBjtGoeqmh0');

$numbers = array($number);
$sender = 'TXTLCL';
$otp = mt_rand(1000,9999);
$message = "This is your OTP: ". $otp;

try {
    $result = $textlocal->sendSms($numbers, $message, $sender);
    //setcookie('otp',$otp);
    $_SESSION["otp"] = $otp;
    $_SESSION['mob']= $number;
    echo "OTP Successfully Send";
} catch (Exception $e) {
    die('Error1: ' . $e->getMessage());
}
}

   if(isset($_POST['verifyotp']))
   {
    $otp= $_POST['otp'];
    //if($_COOKIE['otp']==$otp)
    if($_SESSION["otp"]==$otp)
    {
         /*DataBase Connection  creating table of ustomer by using their mobile number */
      $servername = "localhost";
$username = "root";
$password = "";
$dbname = "customerdetails";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

      echo "Test";
     //  if (mobile = $_SESSION)
      $numberr=$_SESSION['mob'];

       $sql = "INSERT INTO where mobile customeridentity (mobile)
      VALUES ('$numberr')";

     // $cont = "Select mobile from customeridentity";
      // while($row = mysqli_fetch_assoc($cont))

     if (mysqli_query($conn, $sql)) {
       echo "Ok";
      header('Location: http://localhost/MasterProject/dashboard.php');
        } else {
         echo "Error: " . $sql . "<br>" . mysqli_error($conn);
       }



       /* End of database file */

      //header('Location: http://localhost/MasterProject/dashboard.php');

    }
    else
    {
      echo "Not Match";
    }

   }

                  
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</head>
<body>



<div class="container">
  <h2>Vertical (basic) form</h2>
  <form method="post">
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="number" class="form-control" id="email" placeholder="Enter email" name="number" minlength="10" maxlength="10">
      <button type="submit" class="btn btn-default" name="sendotp">Submit</button>
      <br>
      <label for="email">Email:</label>
      <input type="number" class="form-control" id="email" placeholder="Enter email" name="otp" minlength="4" maxlength="4">
    </div>
    
    <button type="submit" class="btn btn-default" name="verifyotp">Submit</button>
    
  </form>
</div>

</body>
</html>