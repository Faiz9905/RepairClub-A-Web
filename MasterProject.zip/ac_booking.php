<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
  <link rel="stylesheet" href="style/styles.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="bootstrap/js/jquery.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
  <script src="bootstrap/js/bootstrap.js"></script>
  <style media="screen">
  .col {
    background-image: url("images/img12.jpg");
    opacity:1;
    height:auto;
  }
  .parallax1{

      background-image: url("images/img16.jpg");
    }
    .parallax2{
      background-image: url("images/img12.jpg");
    }



  </style>
  <title>RepairClub</title>
</head>
<body>










  <nav class="navbar  navbar-expand-sm bg-dark navbar-primary nav1">

  </nav>

  <nav class="navbar navbar-expand-sm bg-light navbar-dark sticky-top nav2">
  <div class="container-fluid">
    <div class="navbar-header">
      <a href="#" class="navbar-brand" style="color:black">RepairClub</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="otpsystem/secondo.php" ><span class="glyphicon glyphicon-user"></span> Sign Up/Login</a></li>

    </ul>
    </div>
  </nav>
